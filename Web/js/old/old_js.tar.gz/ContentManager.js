var ContentManager = function()
 {
    var members = [];
    return {
        getMembers : function(){return this.members;},
        setMembers : function(mem){this.members = mem;},
        
    };
 };
